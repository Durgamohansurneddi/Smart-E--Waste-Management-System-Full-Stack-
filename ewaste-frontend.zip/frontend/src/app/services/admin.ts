import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/auth';
import { Worker, CreateWorkerRequest, ApiResponse } from '../models/ewaste';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AdminService {

  private readonly base = `${environment.apiUrl}/admin`;

  constructor(private http: HttpClient) {}

  // ── User Management ──────────────────────────
  getPendingUsers():  Observable<User[]> { return this.http.get<ApiResponse<User[]>>(`${this.base}/users/pending`).pipe(map(r => r.data)); }
  getApprovedUsers(): Observable<User[]> { return this.http.get<ApiResponse<User[]>>(`${this.base}/users/approved`).pipe(map(r => r.data)); }
  getRejectedUsers(): Observable<User[]> { return this.http.get<ApiResponse<User[]>>(`${this.base}/users/rejected`).pipe(map(r => r.data)); }
  getAllUsers():       Observable<User[]> { return this.http.get<ApiResponse<User[]>>(`${this.base}/users`).pipe(map(r => r.data)); }

  approveUser(id: number): Observable<User> {
    return this.http.put<ApiResponse<User>>(`${this.base}/users/${id}/approve`, {}).pipe(map(r => r.data));
  }

  rejectUser(id: number, reason: string): Observable<User> {
    return this.http.put<ApiResponse<User>>(`${this.base}/users/${id}/reject`, { reason }).pipe(map(r => r.data));
  }

  // ── Worker Management ─────────────────────────
  getAllWorkers():       Observable<Worker[]> { return this.http.get<ApiResponse<Worker[]>>(`${this.base}/workers`).pipe(map(r => r.data)); }
  getAvailableWorkers(): Observable<Worker[]> { return this.http.get<ApiResponse<Worker[]>>(`${this.base}/workers/available`).pipe(map(r => r.data)); }

  /** Creates worker profile + login account */
  createWorker(data: CreateWorkerRequest): Observable<Worker> {
    return this.http.post<ApiResponse<Worker>>(`${this.base}/workers`, data).pipe(map(r => r.data));
  }

  deleteWorker(id: number): Observable<void> {
    return this.http.delete<ApiResponse<void>>(`${this.base}/workers/${id}`).pipe(map(() => undefined));
  }

  updateWorkerStatus(id: number, status: string): Observable<Worker> {
    return this.http.put<ApiResponse<Worker>>(`${this.base}/workers/${id}/status`, { status }).pipe(map(r => r.data));
  }
}
