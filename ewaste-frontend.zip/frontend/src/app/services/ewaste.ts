import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {
  CreateRequestDTO, CreateRequestResponse,
  EwasteRequest, EwasteItem, TimeSlot, ApiResponse
} from '../models/ewaste';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class EwasteService {

  private readonly base = `${environment.apiUrl}/ewaste`;

  constructor(private http: HttpClient) {}

  // ─── Master Data ──────────────────────────────
  getTimeSlots(): Observable<TimeSlot[]> {
    return this.http.get<ApiResponse<TimeSlot[]>>(`${this.base}/timeslots`).pipe(map(r => r.data));
  }

  getAvailableItems(): Observable<EwasteItem[]> {
    return this.http.get<ApiResponse<EwasteItem[]>>(`${this.base}/items`).pipe(map(r => r.data));
  }

  // ─── User ─────────────────────────────────────
  createRequest(payload: CreateRequestDTO): Observable<CreateRequestResponse> {
    return this.http.post<ApiResponse<CreateRequestResponse>>(`${this.base}/user/request`, payload).pipe(map(r => r.data));
  }

  getMyRequests(): Observable<EwasteRequest[]> {
    return this.http.get<ApiResponse<EwasteRequest[]>>(`${this.base}/user/requests`).pipe(map(r => r.data));
  }

  // ─── Admin ────────────────────────────────────
  getAllRequests(): Observable<EwasteRequest[]> {
    return this.http.get<ApiResponse<EwasteRequest[]>>(`${this.base}/admin/requests`).pipe(map(r => r.data));
  }

  getRequestsByStatus(status: string): Observable<EwasteRequest[]> {
    return this.http.get<ApiResponse<EwasteRequest[]>>(`${this.base}/admin/requests/status/${status}`).pipe(map(r => r.data));
  }

  approveAndAssignWorker(requestId: number, workerId: number): Observable<void> {
    return this.http.put<ApiResponse<void>>(`${this.base}/admin/requests/${requestId}/approve`, { workerId }).pipe(map(() => undefined));
  }

  rejectRequest(requestId: number, reason: string): Observable<void> {
    return this.http.put<ApiResponse<void>>(`${this.base}/admin/requests/${requestId}/reject`, { reason }).pipe(map(() => undefined));
  }

  // ─── Worker ───────────────────────────────────
  getMyAssignedRequests(): Observable<EwasteRequest[]> {
    return this.http.get<ApiResponse<EwasteRequest[]>>(`${this.base}/worker/requests`).pipe(map(r => r.data));
  }

  markCompleted(requestId: number): Observable<void> {
    return this.http.put<ApiResponse<void>>(`${this.base}/worker/requests/${requestId}/complete`, {}).pipe(map(() => undefined));
  }
}
