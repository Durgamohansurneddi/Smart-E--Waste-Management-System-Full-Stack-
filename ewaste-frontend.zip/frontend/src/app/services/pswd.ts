import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ApiResponse } from '../models/ewaste';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class PswdService {

  private readonly base = `${environment.apiUrl}/password`;

  constructor(private http: HttpClient) {}

  forgotPassword(email: string): Observable<string> {
    return this.http.post<ApiResponse<string>>(`${this.base}/forgot`, { email })
      .pipe(map(r => r.message));
  }

  verifyOtp(email: string, otp: string): Observable<string> {
    return this.http.post<ApiResponse<string>>(`${this.base}/verify-otp`, { email, otp })
      .pipe(map(r => r.message));
  }

  resetPassword(email: string, newPassword: string): Observable<string> {
    return this.http.post<ApiResponse<string>>(`${this.base}/reset`, { email, newPassword })
      .pipe(map(r => r.message));
  }
}
