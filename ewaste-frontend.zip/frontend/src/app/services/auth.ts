import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { User, Role, RegisterRequest, LoginRequest, WorkerRegisterRequest } from '../models/auth';
import { ApiResponse } from '../models/ewaste';
import { environment } from '../../environments/environment';

export type LoginResult =
  | { type: 'success' }
  | { type: 'aadhaar_required'; email: string; user: User }
  | { type: 'error'; message: string };

@Injectable({ providedIn: 'root' })
export class AuthService {

  private readonly apiUrl = `${environment.apiUrl}/auth`;

  private currentUserSubject = new BehaviorSubject<User | null>(this.loadUser());
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  // ─── Getters ────────────────────────────────────
  get currentUser(): User | null  { return this.currentUserSubject.value; }
  get token(): string | null       { return localStorage.getItem('token'); }
  isAuthenticated(): boolean       { return !!this.token; }
  isAdmin(): boolean               { return this.currentUser?.role === Role.ADMIN; }
  isWorker(): boolean              { return this.currentUser?.role === Role.WORKER; }
  isUser(): boolean                { return this.currentUser?.role === Role.USER; }
  getCurrentUser(): User | null    { return this.currentUser; }

  // ─── Register (user) ────────────────────────────
  register(data: RegisterRequest): Observable<string> {
    return this.http.post<ApiResponse<string>>(`${this.apiUrl}/register`, data).pipe(
      map(r => r.message),
      catchError(this.handleError)
    );
  }

  // ─── Register (worker) ──────────────────────────
  registerWorker(data: WorkerRegisterRequest): Observable<string> {
    return this.http.post<ApiResponse<string>>(`${this.apiUrl}/register-worker`, data).pipe(
      map(r => r.message),
      catchError(this.handleError)
    );
  }

  // ─── Login ──────────────────────────────────────
  // Returns a discriminated union so callers can handle all cases cleanly
  login(email: string, password: string): Observable<LoginResult> {
    const body: LoginRequest = { email, password };
    return this.http.post<ApiResponse<{ token: string; user: User; message: string }>>(
      `${this.apiUrl}/login`, body, { observe: 'response' }
    ).pipe(
      map(httpResp => {
        const res = httpResp.body!;

        // HTTP 202 → AADHAAR_REQUIRED
        if (httpResp.status === 202 && res.message === 'AADHAAR_REQUIRED') {
          return {
            type: 'aadhaar_required' as const,
            email: res.data?.user?.email || email,
            user: res.data?.user
          };
        }

        if (!res.success || !res.data?.token) {
          return { type: 'error' as const, message: res.message || 'Login failed' };
        }

        // Successful login
        const { token, user } = res.data;
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        this.currentUserSubject.next(user);
        this.redirectByRole(user.role);
        return { type: 'success' as const };
      }),
      catchError((err: HttpErrorResponse) => {
        const msg = err.error?.message || 'Login failed. Please try again.';
        return throwError(() => msg);
      })
    );
  }

  // ─── Aadhaar OTP ────────────────────────────────
  sendAadhaarOtp(email: string, aadhaarNumber: string): Observable<string> {
    return this.http.post<ApiResponse<string>>(
      `${this.apiUrl}/worker/aadhaar/send-otp`, { email, aadhaarNumber }
    ).pipe(map(r => r.message), catchError(this.handleError));
  }

  verifyAadhaarOtp(email: string, otp: string): Observable<void> {
    return this.http.post<ApiResponse<{ token: string; user: User }>>(
      `${this.apiUrl}/worker/aadhaar/verify-otp`, { email, otp }
    ).pipe(
      tap(res => {
        if (res.data?.token) {
          localStorage.setItem('token', res.data.token);
          localStorage.setItem('user', JSON.stringify(res.data.user));
          this.currentUserSubject.next(res.data.user);
        }
      }),
      map(() => undefined),
      catchError(this.handleError)
    );
  }

  // ─── Session ────────────────────────────────────
  finishLogin(token: string, user: User): void {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    this.currentUserSubject.next(user);
    this.redirectByRole(user.role);
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.currentUserSubject.next(null);
    this.router.navigate(['/login']);
  }

  redirectByRole(role: Role): void {
    switch (role) {
      case Role.ADMIN:  this.router.navigate(['/admin-dashboard']);  break;
      case Role.WORKER: this.router.navigate(['/worker-dashboard']); break;
      default:          this.router.navigate(['/user-dashboard']);   break;
    }
  }

  private loadUser(): User | null {
    try {
      const s = localStorage.getItem('user');
      return s ? JSON.parse(s) : null;
    } catch { return null; }
  }

  private handleError(err: HttpErrorResponse) {
    const msg = err.error?.message || err.message || 'Request failed';
    return throwError(() => new Error(msg));
  }
}
