import { Pipe, PipeTransform } from '@angular/core';
import { Worker } from '../models/ewaste';

@Pipe({ name: 'statusCount', standalone: true })
export class StatusCountPipe implements PipeTransform {
  transform(workers: Worker[], status: string): number {
    return workers.filter(w => w.status === status).length;
  }
}
