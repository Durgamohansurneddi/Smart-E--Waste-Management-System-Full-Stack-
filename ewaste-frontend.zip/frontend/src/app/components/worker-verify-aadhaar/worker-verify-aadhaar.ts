import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth';

type Step = 'enter-aadhaar' | 'enter-otp';

@Component({
  selector: 'app-worker-verify-aadhaar',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './worker-verify-aadhaar.html',
  styleUrls: ['./worker-verify-aadhaar.css']
})
export class WorkerVerifyAadhaarComponent implements OnInit {

  step: Step = 'enter-aadhaar';
  email = '';
  aadhaarNumber = '';
  otp = '';

  loading = false;
  message = '';
  isError = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.email = this.route.snapshot.queryParams['email'] || '';
    if (!this.email) this.router.navigate(['/login']);
  }

  sendOtp(): void {
    if (!this.aadhaarNumber || this.aadhaarNumber.length !== 12 || !/^\d+$/.test(this.aadhaarNumber)) {
      this.showMsg('Please enter a valid 12-digit Aadhaar number', true);
      return;
    }
    this.loading = true;
    this.authService.sendAadhaarOtp(this.email, this.aadhaarNumber).subscribe({
      next: (msg) => {
        this.loading = false;
        this.step = 'enter-otp';
        this.showMsg('OTP sent! Check the server console for the OTP.', false);
      },
      error: (err) => {
        this.loading = false;
        this.showMsg(err.message || 'Failed to send OTP', true);
      }
    });
  }

  verifyOtp(): void {
    if (!this.otp || this.otp.length !== 6) {
      this.showMsg('Please enter the 6-digit OTP', true);
      return;
    }
    this.loading = true;
    this.authService.verifyAadhaarOtp(this.email, this.otp).subscribe({
      next: () => {
        this.loading = false;
        this.showMsg('✅ Aadhaar verified! Redirecting to dashboard...', false);
        setTimeout(() => this.router.navigate(['/worker-dashboard']), 1500);
      },
      error: (err) => {
        this.loading = false;
        this.showMsg(err.message || 'Invalid OTP. Please try again.', true);
      }
    });
  }

  private showMsg(msg: string, isError: boolean): void {
    this.message = msg;
    this.isError = isError;
  }
}
