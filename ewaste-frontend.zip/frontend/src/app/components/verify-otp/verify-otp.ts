import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PswdService } from '../../services/pswd';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-verify-otp',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './verify-otp.html'
})
export class VerifyOtpComponent implements OnInit {

  email:string="";
  otp:string="";

  constructor(private route:ActivatedRoute,
              private pswdService:PswdService,
              private router:Router){}

  ngOnInit(){

    this.route.queryParams.subscribe(params=>{
      this.email = params['email'];
    });

  }

verifyOtp() {

    this.pswdService.verifyOtp(this.email, this.otp).subscribe({

      next: (res:any) => {

        alert(res.message);

        this.router.navigate(['/reset-password'], {
          queryParams: { email: this.email }
        });

      },

      error: (err) => {

        alert(err.error?.message || "Invalid OTP");

      }

    });

  }

}