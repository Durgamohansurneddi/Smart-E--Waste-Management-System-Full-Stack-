import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { EwasteService } from '../../services/ewaste';
import { AuthService } from '../../services/auth';
import { User } from '../../models/auth';
import { EwasteRequest } from '../../models/ewaste';

@Component({
  selector: 'app-worker-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './worker-dashboard.html',
  styleUrls: ['./worker-dashboard.css']
})
export class WorkerDashboardComponent implements OnInit {

  currentUser: User | null = null;
  requests: EwasteRequest[] = [];
  loading = true;
  activeTab: 'pending' | 'completed' = 'pending';

  toast = '';
  toastOk = true;
  completing: number | null = null;

  constructor(private ewasteService: EwasteService, private authService: AuthService) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.loadAssignedRequests();
  }

  loadAssignedRequests(): void {
    this.loading = true;
    this.ewasteService.getMyAssignedRequests().subscribe({
      next: data => { this.requests = data; this.loading = false; },
      error: () => { this.loading = false; this.showToast('Failed to load pickups', false); }
    });
  }

  get pendingRequests(): EwasteRequest[]   { return this.requests.filter(r => r.status === 'APPROVED'); }
  get completedRequests(): EwasteRequest[] { return this.requests.filter(r => r.status === 'COMPLETED'); }

  markComplete(id: number): void {
    this.completing = id;
    this.ewasteService.markCompleted(id).subscribe({
      next: () => {
        this.completing = null;
        this.showToast('✅ Pickup marked as completed!', true);
        this.loadAssignedRequests(); // Refresh full list
      },
      error: (e) => {
        this.completing = null;
        this.showToast(e?.error?.message || 'Failed to update', false);
      }
    });
  }

  setTab(tab: 'pending' | 'completed'): void { this.activeTab = tab; }

  private showToast(msg: string, ok: boolean): void {
    this.toast = msg; this.toastOk = ok;
    setTimeout(() => this.toast = '', 3500);
  }

  logout(): void { this.authService.logout(); }
}
