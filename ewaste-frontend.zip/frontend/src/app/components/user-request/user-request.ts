import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { EwasteService } from '../../services/ewaste';
import { AuthService } from '../../services/auth';
import { User } from '../../models/auth';
import {
  CreateRequestDTO, CartItem, EwasteRequest,
  TimeSlot, EwasteItem
} from '../../models/ewaste';

@Component({
  selector: 'app-user-request',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './user-request.html',
  styleUrls: ['./user-request.css']
})
export class UserRequestComponent implements OnInit {

  currentUser: User | null = null;
  activeTab: 'booking' | 'my-requests' = 'booking';

  // Booking form
  today = new Date().toISOString().slice(0, 10);
  address = '';
  preferredDate = new Date().toISOString().slice(0, 10);
  selectedTimeSlotId: number | null = null;
  selectedItemId: number | null = null;
  selectedQty = 1;

  timeSlots: TimeSlot[] = [];
  availableItems: EwasteItem[] = [];
  cart: CartItem[] = [];

  formMsg = '';
  formSuccess = false;
  submitting = false;

  // My Requests
  myRequests: EwasteRequest[] = [];
  requestsLoading = false;

  constructor(
    private ewasteService: EwasteService,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.ewasteService.getTimeSlots().subscribe({ next: s => { this.timeSlots = s; if (s.length) this.selectedTimeSlotId = s[0].id; } });
    this.ewasteService.getAvailableItems().subscribe({ next: i => { this.availableItems = i; if (i.length) this.selectedItemId = i[0].id; } });

    this.route.queryParamMap.subscribe(p => {
      const view = p.get('view');
      this.activeTab = view === 'my-requests' ? 'my-requests' : 'booking';
      if (this.activeTab === 'my-requests') this.loadMyRequests();
    });
  }

  setTab(tab: 'booking' | 'my-requests'): void {
    this.activeTab = tab;
    this.router.navigate([], { relativeTo: this.route, queryParams: { view: tab === 'my-requests' ? 'my-requests' : null }, queryParamsHandling: 'merge' });
    if (tab === 'my-requests') this.loadMyRequests();
  }

  // ─── Cart ─────────────────────────────────────
  addToCart(): void {
    if (!this.selectedItemId || this.selectedQty < 1) {
      this.formMsg = 'Select a valid item and quantity';
      this.formSuccess = false;
      return;
    }
    const item = this.availableItems.find(i => i.id === +this.selectedItemId!);
    if (!item) return;
    const existing = this.cart.find(c => c.itemId === item.id);
    if (existing) {
      existing.quantity += this.selectedQty;
    } else {
      this.cart.push({ itemId: item.id, quantity: this.selectedQty, itemName: item.name });
    }
    this.selectedQty = 1;
    this.formMsg = '';
  }

  removeFromCart(index: number): void { this.cart.splice(index, 1); }

  get cartTotalPoints(): number {
    return this.cart.reduce((sum, c) => sum + c.quantity * 10, 0);
  }

  get cartTotalItems(): number {
    return this.cart.reduce((sum, c) => sum + c.quantity, 0);
  }

  // ─── Submit ───────────────────────────────────
  submitRequest(): void {
    this.formMsg = '';
    if (!this.address.trim())        { this.formMsg = 'Please enter pickup address'; return; }
    if (!this.preferredDate)         { this.formMsg = 'Please select a date'; return; }
    if (!this.selectedTimeSlotId)    { this.formMsg = 'Please select a time slot'; return; }
    if (this.cart.length === 0)      { this.formMsg = 'Add at least one item to proceed'; return; }

    const today = new Date().toISOString().slice(0, 10);
    if (this.preferredDate < today)  { this.formMsg = 'Preferred date cannot be in the past'; return; }

    this.submitting = true;
    const payload: CreateRequestDTO = {
      address:       this.address,
      preferredDate: this.preferredDate,
      timeSlotId:    +this.selectedTimeSlotId,
      items:         this.cart.map(c => ({ itemId: c.itemId, quantity: c.quantity }))
    };

    this.ewasteService.createRequest(payload).subscribe({
      next: res => {
        this.submitting = false;
        this.formSuccess = true;
        this.formMsg = `✅ ${res.message} (Request #${res.requestId})`;
        this.cart = [];
        this.address = '';
        this.preferredDate = new Date().toISOString().slice(0, 10);
      },
      error: e => {
        this.submitting = false;
        this.formSuccess = false;
        this.formMsg = e?.error?.message || 'Submission failed. Please try again.';
      }
    });
  }

  // ─── My Requests ──────────────────────────────
  loadMyRequests(): void {
    this.requestsLoading = true;
    this.ewasteService.getMyRequests().subscribe({
      next: d => { this.myRequests = d.slice().reverse(); this.requestsLoading = false; },
      error: () => { this.requestsLoading = false; }
    });
  }

  getSlotLabel(slotId?: number): string {
    if (!slotId) return '—';
    const slot = this.timeSlots.find(s => s.id === slotId);
    return slot ? slot.slotLabel : `Slot #${slotId}`;
  }

  getStatusClass(s: string): string { return `badge badge-${s.toLowerCase()}`; }
  logout(): void { this.authService.logout(); }
}
