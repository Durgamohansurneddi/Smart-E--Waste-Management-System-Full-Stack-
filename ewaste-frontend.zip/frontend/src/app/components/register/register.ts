import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth'; 
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})

export class RegisterComponent implements OnInit {
  registerForm!: FormGroup;
  loading = false;
  submitted = false;
  errorMessage = '';
  successMessage = '';
  showPassword = false;
  showConfirmPassword = false;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/dashboard']);
    }
    this.initializeForm();
  }

  initializeForm(): void {
    this.registerForm = this.formBuilder.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      username: ['', [Validators.required, Validators.minLength(3)]],
      phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');

    if (!password || !confirmPassword) {
      return null;
    }

    return password.value === confirmPassword.value ? null : { passwordMismatch: true };
  }

  get f() {
    return this.registerForm.controls;
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  toggleConfirmPasswordVisibility(): void {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  onSubmit(): void {
    this.submitted = true;
    this.errorMessage = '';
    this.successMessage = '';

    if (this.registerForm.invalid) {
      return;
    }

    this.loading = true;
    // Add this right after this.loading = true;

    const registerData = {
      name: this.f['name'].value,
      username: this.f['username'].value,
      phone: this.f['phone'].value,
      email: this.f['email'].value,
      password: this.f['password'].value
    };


    this.authService.register(registerData).subscribe({
      next: (response) => {
        this.loading = false;
        
        // Show success message
        this.successMessage = '✅ Registration successful! Redirecting to login in 2 seconds...';
        
        // Reset form
        this.registerForm.reset();
        this.submitted = false;

        // Redirect to login after 2 seconds
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 2000);
      },
      error: (error) => {
        this.loading = false;
        
        // Handle different error messages
        if (error.message && error.message.includes('Email already registered')) {
          this.errorMessage = '❌ Email already registered. Please use a different email.';
        } else if (error.message && error.message.includes('Username already taken')) {
          this.errorMessage = '❌ Username already taken. Please choose a different username.';
        } else {
          this.errorMessage = error.message || '❌ Registration failed. Please try again.';
        }
      }
    });
  }

  getErrorMessage(fieldName: string): string {
    const control = this.f[fieldName];
    
    if (control?.hasError('required')) {
      return `${this.capitalize(fieldName)} is required`;
    }
    if (control?.hasError('email')) {
      return 'Please enter a valid email';
    }
    if (control?.hasError('minlength')) {
      return `${this.capitalize(fieldName)} must be at least ${control.getError('minlength').requiredLength} characters`;
    }
    if (control?.hasError('pattern')) {
      return 'Phone number must be 10 digits';
    }
    
    return '';
  }

  private capitalize(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
}