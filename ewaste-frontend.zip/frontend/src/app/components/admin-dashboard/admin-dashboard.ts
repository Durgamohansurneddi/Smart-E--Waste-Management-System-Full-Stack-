import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../services/admin';
import { AuthService } from '../../services/auth';
import { User } from '../../models/auth';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboardComponent implements OnInit {

  currentUser: User | null = null;
  mainSection = 'users';
  activeTab = 'pending';

  pendingUsers: any[] = [];
  approvedUsers: any[] = [];
  rejectedUsers: any[] = [];
  allUsers: any[] = [];

  loading = false;
  actionMsg = '';
  actionSuccess = true;

  showRejectModal = false;
  rejectTargetId: number | null = null;
  rejectTargetName = '';
  rejectReason = '';
  rejectSubmitting = false;

  constructor(private authService: AuthService, private adminService: AdminService) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.loadPendingUsers();
  }

  setSection(section: string): void {
    this.mainSection = section;
    if (section === 'users') this.setActiveTab('pending');
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
    this.actionMsg = '';
    if (tab === 'pending')  this.loadPendingUsers();
    if (tab === 'approved') this.loadApprovedUsers();
    if (tab === 'rejected') this.loadRejectedUsers();
    if (tab === 'all')      this.loadAllUsers();
  }

  loadPendingUsers():  void { this.loading = true; this.adminService.getPendingUsers().subscribe({ next: d => { this.pendingUsers = d; this.loading = false; }, error: () => this.loading = false }); }
  loadApprovedUsers(): void { this.loading = true; this.adminService.getApprovedUsers().subscribe({ next: d => { this.approvedUsers = d; this.loading = false; }, error: () => this.loading = false }); }
  loadRejectedUsers(): void { this.loading = true; this.adminService.getRejectedUsers().subscribe({ next: d => { this.rejectedUsers = d; this.loading = false; }, error: () => this.loading = false }); }
  loadAllUsers():      void { this.loading = true; this.adminService.getAllUsers().subscribe({ next: d => { this.allUsers = d; this.loading = false; }, error: () => this.loading = false }); }

  approveUser(id: number, name: string): void {
    this.adminService.approveUser(id).subscribe({
      next: () => { this.showToast(`✅ ${name} approved`, true); this.loadPendingUsers(); },
      error: () => this.showToast('Approval failed', false)
    });
  }

  openRejectModal(id: number, name: string): void { this.rejectTargetId = id; this.rejectTargetName = name; this.rejectReason = ''; this.showRejectModal = true; }
  closeRejectModal(): void { this.showRejectModal = false; this.rejectTargetId = null; this.rejectReason = ''; }

  submitRejectUser(): void {
    if (!this.rejectReason.trim()) return;
    this.rejectSubmitting = true;
    this.adminService.rejectUser(this.rejectTargetId!, this.rejectReason).subscribe({
      next: () => { this.rejectSubmitting = false; this.showToast(`❌ ${this.rejectTargetName} rejected`, true); this.closeRejectModal(); this.loadPendingUsers(); },
      error: () => { this.rejectSubmitting = false; this.showToast('Rejection failed', false); }
    });
  }

  reApproveUser(id: number, name: string): void {
    this.adminService.approveUser(id).subscribe({
      next: () => { this.showToast(`✅ ${name} re-approved`, true); this.loadRejectedUsers(); },
      error: () => this.showToast('Action failed', false)
    });
  }

  private showToast(msg: string, success: boolean): void {
    this.actionMsg = msg; this.actionSuccess = success;
    setTimeout(() => this.actionMsg = '', 3500);
  }

  getStatusClass(s: string): string { return `badge badge-${s.toLowerCase()}`; }
  logout(): void { this.authService.logout(); }
}
