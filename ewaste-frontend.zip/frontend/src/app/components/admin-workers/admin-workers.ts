import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AdminService } from '../../services/admin';
import { AuthService } from '../../services/auth';
import { Worker, CreateWorkerRequest } from '../../models/ewaste';
import { StatusCountPipe } from '../../pipes/status-count.pipe';

@Component({
  selector: 'app-admin-workers',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, StatusCountPipe],
  templateUrl: './admin-workers.html',
  styleUrls: ['./admin-workers.css']
})
export class AdminWorkersComponent implements OnInit {

  workers: Worker[] = [];
  loading = false;
  toast = '';
  toastOk = true;

  showAddModal = false;
  addSubmitting = false;
  newWorker: CreateWorkerRequest = { name: '', username: '', email: '', phone: '', password: '' };
  addError = '';

  showDeleteModal = false;
  deleteTargetId: number | null = null;
  deleteTargetName = '';

  constructor(private adminService: AdminService, private authService: AuthService) {}

  ngOnInit(): void { this.loadWorkers(); }

  loadWorkers(): void {
    this.loading = true;
    this.adminService.getAllWorkers().subscribe({
      next: w => { this.workers = w; this.loading = false; },
      error: () => { this.loading = false; this.showToast('Failed to load workers', false); }
    });
  }

  openAddModal(): void {
    this.newWorker = { name: '', username: '', email: '', phone: '', password: '' };
    this.addError = '';
    this.showAddModal = true;
  }
  closeAddModal(): void { this.showAddModal = false; }

  submitAddWorker(): void {
    const { name, username, email, phone, password } = this.newWorker;
    if (!name || !username || !email || !phone || !password) {
      this.addError = 'All fields are required'; return;
    }
    if (!/^\d{10}$/.test(phone)) {
      this.addError = 'Phone must be 10 digits'; return;
    }
    if (password.length < 6) {
      this.addError = 'Password must be at least 6 characters'; return;
    }
    this.addSubmitting = true;
    this.addError = '';
    this.adminService.createWorker(this.newWorker).subscribe({
      next: () => {
        this.addSubmitting = false;
        this.showToast(`✅ Worker "${name}" created with login access`, true);
        this.closeAddModal();
        this.loadWorkers();
      },
      error: (e) => {
        this.addSubmitting = false;
        this.addError = e?.error?.message || 'Failed to create worker';
      }
    });
  }

  openDeleteModal(id: number, name: string): void {
    this.deleteTargetId = id; this.deleteTargetName = name;
    this.showDeleteModal = true;
  }
  closeDeleteModal(): void { this.showDeleteModal = false; }

  confirmDelete(): void {
    this.adminService.deleteWorker(this.deleteTargetId!).subscribe({
      next: () => {
        this.showToast(`🗑 Worker "${this.deleteTargetName}" removed`, true);
        this.closeDeleteModal();
        this.loadWorkers();
      },
      error: (e) => this.showToast(e?.error?.message || 'Delete failed', false)
    });
  }

  getStatusClass(s: string): string { return `badge badge-worker-${s.toLowerCase()}`; }
  private showToast(msg: string, ok: boolean): void {
    this.toast = msg; this.toastOk = ok;
    setTimeout(() => this.toast = '', 3500);
  }
  logout(): void { this.authService.logout(); }
}
