import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  loading = false;
  submitted = false;
  errorMessage = '';
  showPassword = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // If already authenticated, go to correct dashboard
    if (this.authService.isAuthenticated()) {
      this.authService.redirectByRole(this.authService.currentUser!.role);
      return;
    }
    this.loginForm = this.fb.group({
      email:    ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  get f() { return this.loginForm.controls; }

  togglePasswordVisibility(): void { this.showPassword = !this.showPassword; }

  onSubmit(): void {
    this.submitted = true;
    this.errorMessage = '';
    if (this.loginForm.invalid) return;

    this.loading = true;
    const email    = this.f['email'].value;
    const password = this.f['password'].value;

    this.authService.login(email, password).subscribe({
      next: (result) => {
        this.loading = false;
        if (result.type === 'success') {
          // redirectByRole already called inside auth service
        } else if (result.type === 'aadhaar_required') {
          // Worker needs Aadhaar verification
          this.router.navigate(['/worker-verify-aadhaar'], {
            queryParams: { email: result.email }
          });
        } else {
          this.errorMessage = result.message;
        }
      },
      error: (msg) => {
        this.loading = false;
        this.errorMessage = msg || 'Login failed. Please try again.';
      }
    });
  }

  getErrorMessage(field: string): string {
    const c = this.f[field];
    if (c?.hasError('required')) return `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
    if (c?.hasError('email'))    return 'Please enter a valid email address';
    if (c?.hasError('minlength')) return `Password must be at least ${c.getError('minlength').requiredLength} characters`;
    return '';
  }
}
