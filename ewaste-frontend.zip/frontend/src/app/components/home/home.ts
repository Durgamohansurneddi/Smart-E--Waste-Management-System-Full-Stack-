import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AuthService } from '../../services/auth'; 
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

interface HeroImage {
  url: string;
  alt: string;
}

interface Testimonial {
  id: number;
  name: string;
  role: string;
  image: string;
  comment: string;
  rating: number;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class HomeComponent implements OnInit {
  @ViewChild('processScroll') processScroll!: ElementRef;

  isAuthenticated = false;
  currentImageIndex = 0;
  currentTestimonialIndex = 0;

  // Hero Images
  heroImages: HeroImage[] = [
    {
      url: 'https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=1200&h=600&fit=crop',
      alt: 'E-waste recycling facility'
    },
    {
      url: 'https://images.unsplash.com/photo-1532996122724-8f3c2cd83c5d?w=1200&h=600&fit=crop',
      alt: 'Electronic devices'
    },
    {
      url: 'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=1200&h=600&fit=crop',
      alt: 'Green technology'
    },
    {
      url: 'https://images.unsplash.com/photo-1556075798-4825dfaaf498?w=1200&h=600&fit=crop',
      alt: 'Sustainable future'
    }
  ];

  // Testimonials Data
  testimonials: Testimonial[] = [
    {
      id: 1,
      name: 'Rajesh Kumar',
      role: 'Business Owner',
      image: 'https://i.pravatar.cc/150?img=1',
      comment: 'E-Waste Hub made it incredibly easy to dispose of our old office equipment. The free pickup service was a game-changer!',
      rating: 5
    },
    {
      id: 2,
      name: 'Priya Singh',
      role: 'Environmental Activist',
      image: 'https://i.pravatar.cc/150?img=5',
      comment: 'Finally, a platform that takes e-waste seriously. I love the detailed impact reports they provide.',
      rating: 5
    },
    {
      id: 3,
      name: 'Amit Patel',
      role: 'Tech Enthusiast',
      image: 'https://i.pravatar.cc/150?img=10',
      comment: 'Data security was my main concern, but their certificate of destruction gave me complete peace of mind.',
      rating: 5
    },
    {
      id: 4,
      name: 'Neha Desai',
      role: 'Corporate Manager',
      image: 'https://i.pravatar.cc/150?img=15',
      comment: 'We recycle all our company electronics through E-Waste Hub. Transparent, reliable, and eco-friendly!',
      rating: 5
    },
    {
      id: 5,
      name: 'Vikram Sharma',
      role: 'Home User',
      image: 'https://i.pravatar.cc/150?img=20',
      comment: 'Best experience! Quick response, professional service, and they even came on the weekend.',
      rating: 5
    },
    {
      id: 6,
      name: 'Anjali Verma',
      role: 'Student',
      image: 'https://i.pravatar.cc/150?img=25',
      comment: 'Great initiative! I earned points for recycling my old laptop and redeemed them for rewards.',
      rating: 5
    }
  ];

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    // Subscribe to authentication status
    this.authService.currentUser$.subscribe(user => {
      this.isAuthenticated = !!user;
    });

    // Check if already authenticated
    const user = this.authService.getCurrentUser();
    if (user) {
      this.isAuthenticated = true;
    }

    // Auto-rotate hero images
    this.startHeroAutoRotate();
  }

  // ===== HERO CAROUSEL METHODS =====
  startHeroAutoRotate(): void {
    setInterval(() => {
      this.nextHeroImage();
    }, 5000); // Change image every 5 seconds
  }

  nextHeroImage(): void {
    this.currentImageIndex = (this.currentImageIndex + 1) % this.heroImages.length;
  }

  prevHeroImage(): void {
    this.currentImageIndex = (this.currentImageIndex - 1 + this.heroImages.length) % this.heroImages.length;
  }

  // ===== PROCESS CAROUSEL METHODS =====
  scrollProcess(direction: string): void {
    if (!this.processScroll) return;

    const scrollElement = this.processScroll.nativeElement;
    const scrollAmount = 300;

    if (direction === 'left') {
      scrollElement.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    } else {
      scrollElement.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  }

  // ===== TESTIMONIALS CAROUSEL METHODS =====
  getDisplayedTestimonials(): Testimonial[] {
    const displayed: Testimonial[] = [];
    displayed.push(this.testimonials[this.currentTestimonialIndex]);
    
    // Show 2 testimonials at a time on desktop
    if (this.currentTestimonialIndex + 1 < this.testimonials.length) {
      displayed.push(this.testimonials[this.currentTestimonialIndex + 1]);
    }
    
    return displayed;
  }

  nextTestimonial(): void {
    this.currentTestimonialIndex = (this.currentTestimonialIndex + 2) % this.testimonials.length;
  }

  prevTestimonial(): void {
    this.currentTestimonialIndex = (this.currentTestimonialIndex - 2 + this.testimonials.length) % this.testimonials.length;
  }

  getRatingArray(rating: number): number[] {
    return Array(rating).fill(0);
  }

  // ===== LOGIN MODAL =====
  openLoginModal(): void {
    if (!this.isAuthenticated) {
      // Navigate to login page
      window.location.href = '/login';
    } else {
      // Already authenticated, go to dashboard
      window.location.href = '/user-dashboard';
    }
  }
}