import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PswdService } from '../../services/pswd'; 
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './reset-password.html'
})
export class ResetPasswordComponent implements OnInit {

  email:string="";
  newPassword:string="";

  constructor(private route:ActivatedRoute,
              private pswdService:PswdService,
              private router:Router){}

  ngOnInit(){

    this.route.queryParams.subscribe(params=>{
      this.email = params['email'];
    });

  }

  resetPassword() {

    this.pswdService.resetPassword(this.email, this.newPassword).subscribe({

      next: (res:any) => {

        alert(res.message);

        this.router.navigate(['/login']);

      },

      error: (err) => {

        alert(err.error?.message || "Password reset failed");

      }

    });

  }

}