import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PswdService } from '../../services/pswd';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './forgot-password.html'
})
export class ForgotPasswordComponent {

  email: string = "";

  constructor(private pswdService: PswdService,
              private router: Router) {}

sendOtp() {

  this.pswdService.forgotPassword(this.email).subscribe((res:any)=>{

    alert(res.message);

    this.router.navigate(['/verify-otp'],{
      queryParams:{email:this.email}
    });

  });

}

}