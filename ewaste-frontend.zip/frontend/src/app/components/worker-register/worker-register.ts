import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-worker-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './worker-register.html',
  styleUrls: ['./worker-register.css']
})
export class WorkerRegisterComponent {
  form!: FormGroup;
  loading = false;
  submitted = false;
  successMessage = '';
  errorMessage = '';
  showPassword = false;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.form = this.fb.group({
      name:          ['', [Validators.required, Validators.minLength(3)]],
      username:      ['', [Validators.required, Validators.minLength(3)]],
      email:         ['', [Validators.required, Validators.email]],
      phone:         ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      vehicleNumber: ['', [Validators.required, Validators.minLength(5)]],
      licenceNumber: ['', [Validators.required, Validators.minLength(5)]],
      password:      ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatch });
  }

  passwordMatch(g: AbstractControl): ValidationErrors | null {
    return g.get('password')?.value === g.get('confirmPassword')?.value
      ? null : { passwordMismatch: true };
  }

  get f() { return this.form.controls; }

  onSubmit(): void {
    this.submitted = true;
    this.errorMessage = '';
    if (this.form.invalid) return;

    this.loading = true;
    const { name, username, email, phone, vehicleNumber, licenceNumber, password } = this.form.value;

    this.authService.registerWorker({ name, username, email, phone, vehicleNumber, licenceNumber, password })
      .subscribe({
        next: (msg) => {
          this.loading = false;
          this.successMessage = '✅ ' + msg;
          setTimeout(() => this.router.navigate(['/login']), 3000);
        },
        error: (err) => {
          this.loading = false;
          this.errorMessage = err.message || 'Registration failed. Please try again.';
        }
      });
  }
}
