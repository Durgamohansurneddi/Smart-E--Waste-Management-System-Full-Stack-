import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth';
import { EwasteService } from '../../services/ewaste';
import { User } from '../../models/auth';
import { EwasteRequest } from '../../models/ewaste';

@Component({
  selector: 'app-user-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './user-dashboard.html',
  styleUrls: ['./user-dashboard.css']
})
export class UserDashboardComponent implements OnInit {

  currentUser: User | null = null;
  recentRequests: EwasteRequest[] = [];
  loading = true;

  stats = { total: 0, approved: 0, pending: 0, completed: 0, points: 0 };

  constructor(
    private authService: AuthService,
    private ewasteService: EwasteService
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.loadData();
  }

  loadData(): void {
    this.ewasteService.getMyRequests().subscribe({
      next: requests => {
        this.recentRequests = requests.slice().reverse().slice(0, 5);
        this.stats.total     = requests.length;
        this.stats.approved  = requests.filter(r => r.status === 'APPROVED' || r.status === 'COMPLETED').length;
        this.stats.pending   = requests.filter(r => r.status === 'PENDING').length;
        this.stats.completed = requests.filter(r => r.status === 'COMPLETED').length;
        this.stats.points    = requests
          .filter(r => r.status === 'COMPLETED')
          .reduce((sum, r) => sum + (r.items || []).reduce((s, i) => s + i.quantity * 10, 0), 0);
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }

  getStatusClass(s: string): string { return `badge badge-${s.toLowerCase()}`; }
  logout(): void { this.authService.logout(); }
}
