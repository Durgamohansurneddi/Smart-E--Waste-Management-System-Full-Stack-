import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../services/auth';
import { User, Role } from '../../models/auth';

@Component({
  selector: 'app-home-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home-navbar.html',
  styleUrls: ['./home-navbar.css']
})
export class NavbarComponent implements OnInit {

  currentUser: User | null = null;
  isAuthenticated = false;
  isMenuOpen = false;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      this.isAuthenticated = !!user;
    });
  }

  isAdmin():  boolean { return this.currentUser?.role === Role.ADMIN; }
  isWorker(): boolean { return this.currentUser?.role === Role.WORKER; }

  getDashboardRoute(): string {
    if (this.isAdmin())  return '/admin-dashboard';
    if (this.isWorker()) return '/worker-dashboard';
    return '/user-dashboard';
  }

  toggleMenu(): void { this.isMenuOpen = !this.isMenuOpen; }
  closeMenu():  void { this.isMenuOpen = false; }

  logout(): void { this.authService.logout(); this.closeMenu(); }
}
