import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home-footer',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home-footer.html',
  styleUrls: ['./home-footer.css']
})
export class HomeFooterComponent {
  currentYear: number = new Date().getFullYear();

  // Social links
  socialLinks = [
    { icon: 'f', name: 'Facebook', url: '#' },
    { icon: '𝕏', name: 'Twitter', url: '#' },
    { icon: 'in', name: 'LinkedIn', url: '#' }
  ];

  // Quick links
  quickLinks = [
    { label: 'About Us', url: '#about' },
    { label: 'How It Works', url: '#how-it-works' },
    { label: 'Contact', url: '#contact' },
    { label: 'Privacy Policy', url: '#' }
  ];

  // Contact info
  contactInfo = [
    { label: 'Email', value: 'info@ewastehu.com' },
    { label: 'Phone', value: '+91 123456789' },
    { label: 'Hours', value: 'Mon - Fri, 9AM - 6PM' }
  ];

  scrollToSection(sectionId: string): void {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }
}