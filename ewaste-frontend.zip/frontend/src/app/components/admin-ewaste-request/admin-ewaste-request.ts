import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { EwasteService } from '../../services/ewaste';
import { AdminService } from '../../services/admin';
import { AuthService } from '../../services/auth';
import { EwasteRequest, Worker } from '../../models/ewaste';

@Component({
  selector: 'app-admin-ewaste-request',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-ewaste-request.html',
  styleUrls: ['./admin-ewaste-request.css']
})
export class AdminEwasteRequestComponent implements OnInit {

  requests: EwasteRequest[] = [];
  filteredRequests: EwasteRequest[] = [];
  availableWorkers: Worker[] = [];
  loading = false;
  activeStatus: 'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED' = 'ALL';

  toast = '';
  toastOk = true;

  // Approve modal
  showApproveModal = false;
  approveTargetId: number | null = null;
  selectedWorkerId: number | null = null;
  approveSubmitting = false;

  // Reject modal
  showRejectModal = false;
  rejectTargetId: number | null = null;
  rejectReason = '';
  rejectSubmitting = false;

  // Items modal
  showItemsModal = false;
  selectedRequest: EwasteRequest | null = null;

  constructor(
    private ewasteService: EwasteService,
    private adminService: AdminService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadRequests();
    this.loadAvailableWorkers();
  }

  loadAvailableWorkers(): void {
    this.adminService.getAvailableWorkers().subscribe({
      next: w => this.availableWorkers = w,
      error: () => {}
    });
  }

  loadRequests(): void {
    this.loading = true;
    this.ewasteService.getAllRequests().subscribe({
      next: data => {
        this.requests = data;
        this.applyFilter();
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.showToast('Failed to load requests', false);
      }
    });
  }

  setFilter(status: typeof this.activeStatus): void {
    this.activeStatus = status;
    this.applyFilter();
  }

  applyFilter(): void {
    this.filteredRequests = this.activeStatus === 'ALL'
      ? [...this.requests]
      : this.requests.filter(r => r.status === this.activeStatus);
  }

  counts() {
    return {
      all:       this.requests.length,
      pending:   this.requests.filter(r => r.status === 'PENDING').length,
      approved:  this.requests.filter(r => r.status === 'APPROVED').length,
      rejected:  this.requests.filter(r => r.status === 'REJECTED').length,
      completed: this.requests.filter(r => r.status === 'COMPLETED').length,
    };
  }

  // ─── Approve ──────────────────────────────────
  openApproveModal(id: number): void {
    this.approveTargetId = id;
    this.selectedWorkerId = null;
    this.loadAvailableWorkers();
    this.showApproveModal = true;
  }

  closeApproveModal(): void {
    this.showApproveModal = false;
    this.approveTargetId = null;
    this.selectedWorkerId = null;
  }

  submitApprove(): void {
    if (!this.selectedWorkerId) return;
    this.approveSubmitting = true;
    this.ewasteService.approveAndAssignWorker(this.approveTargetId!, +this.selectedWorkerId).subscribe({
      next: () => {
        this.approveSubmitting = false;
        this.showToast('✅ Request approved and worker assigned', true);
        this.closeApproveModal();
        this.loadRequests();
        this.loadAvailableWorkers();
      },
      error: (e) => {
        this.approveSubmitting = false;
        this.showToast(e?.error?.message || 'Approval failed', false);
      }
    });
  }

  // ─── Reject ───────────────────────────────────
  openRejectModal(id: number): void {
    this.rejectTargetId = id;
    this.rejectReason = '';
    this.showRejectModal = true;
  }

  closeRejectModal(): void {
    this.showRejectModal = false;
    this.rejectTargetId = null;
    this.rejectReason = '';
  }

  submitReject(): void {
    if (!this.rejectReason.trim()) return;
    this.rejectSubmitting = true;
    this.ewasteService.rejectRequest(this.rejectTargetId!, this.rejectReason).subscribe({
      next: () => {
        this.rejectSubmitting = false;
        this.showToast('❌ Request rejected', true);
        this.closeRejectModal();
        this.loadRequests();
      },
      error: (e) => {
        this.rejectSubmitting = false;
        this.showToast(e?.error?.message || 'Reject failed', false);
      }
    });
  }

  // ─── Items ────────────────────────────────────
  viewItems(req: EwasteRequest): void {
    this.selectedRequest = req;
    this.showItemsModal = true;
  }

  closeItemsModal(): void { this.showItemsModal = false; }

  private showToast(msg: string, ok: boolean): void {
    this.toast = msg; this.toastOk = ok;
    setTimeout(() => this.toast = '', 4000);
  }

  getStatusClass(s: string): string { return `badge badge-${s.toLowerCase()}`; }
  logout(): void { this.authService.logout(); }
}
