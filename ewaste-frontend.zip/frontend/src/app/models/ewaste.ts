// ─── Master Data ─────────────────────────────────
export interface TimeSlot {
  id: number;
  slotLabel: string;
  startTime: string;
  endTime: string;
}

export interface EwasteItem {
  id: number;
  name: string;
}

// ─── Worker ──────────────────────────────────────
export interface Worker {
  id: number;
  name: string;
  email: string;
  phone: string;
  status: 'AVAILABLE' | 'ASSIGNED' | 'ON_LEAVE';
  createdAt?: string;
}

/** Sent to POST /api/admin/workers — creates both login account and worker profile */
export interface CreateWorkerRequest {
  name: string;
  username: string;
  email: string;
  phone: string;
  password: string;
}

// ─── Request Flow ────────────────────────────────
export interface ItemDTO {
  itemId: number;
  quantity: number;
}

export interface CartItem extends ItemDTO {
  itemName: string;
}

export interface CreateRequestDTO {
  items: ItemDTO[];
  address: string;
  preferredDate: string;
  timeSlotId: number;
}

export interface CreateRequestResponse {
  requestId: number;
  message: string;
}

export interface RequestItem {
  id: number;
  requestId: number;
  itemId: number;
  quantity: number;
  itemName?: string;
}

export interface EwasteRequest {
  id: number;
  userId: number;
  address: string;
  preferredDate: string;
  timeSlotId: number;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED';
  adminRemarks?: string;
  assignedWorker?: Worker;
  items?: RequestItem[];
  createdAt?: string;
  approvedAt?: string;
}

// ─── API Wrapper ─────────────────────────────────
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}
