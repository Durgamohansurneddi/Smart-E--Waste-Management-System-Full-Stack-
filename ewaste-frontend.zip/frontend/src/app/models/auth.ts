export enum Role {
  USER   = 'USER',
  ADMIN  = 'ADMIN',
  WORKER = 'WORKER'
}

export enum Status {
  PENDING  = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED'
}

export interface User {
  id: number;
  name: string;
  username: string;
  phone: string;
  email: string;
  role: Role;
  status: Status;
  createdAt?: string;
}

export interface RegisterRequest {
  name: string;
  username: string;
  phone: string;
  email: string;
  password: string;
}

export interface WorkerRegisterRequest {
  name: string;
  username: string;
  phone: string;
  email: string;
  password: string;
  vehicleNumber: string;
  licenceNumber: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  user: User;
  message: string;
}
