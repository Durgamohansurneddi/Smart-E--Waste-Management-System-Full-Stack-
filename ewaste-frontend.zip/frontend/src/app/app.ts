import { Component } from '@angular/core';
import { Router, RouterOutlet, NavigationEnd } from '@angular/router';
import { NavbarComponent } from './components/home-navbar/home-navbar';
import { HomeFooterComponent } from './components/home-footer/home-footer';
import { CommonModule } from '@angular/common';

const DASHBOARD_ROUTES = [
  '/admin-dashboard', '/admin-requests', '/admin-workers',
  '/user-dashboard', '/user-request', '/worker-dashboard'
];

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, NavbarComponent, HomeFooterComponent],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {
  title = 'EWaste Hub';

  constructor(public router: Router) {}

  isPublicRoute(): boolean {
    const url = this.router.url.split('?')[0];
    return !DASHBOARD_ROUTES.some(r => url.startsWith(r));
  }
}
