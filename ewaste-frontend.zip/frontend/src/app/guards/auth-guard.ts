import { inject } from '@angular/core';
import { CanActivateFn, Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService } from '../services/auth';
import { Role } from '../models/auth';

export const authGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state) => {
  const auth   = inject(AuthService);
  const router = inject(Router);

  if (!auth.isAuthenticated()) {
    router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }

  const requiredRoles: Role[] = route.data?.['roles'];
  if (requiredRoles?.length) {
    const userRole = auth.currentUser?.role;
    if (!userRole || !requiredRoles.includes(userRole)) {
      // Redirect to their own dashboard rather than login
      if (auth.isAdmin())  router.navigate(['/admin-dashboard']);
      else if (auth.isWorker()) router.navigate(['/worker-dashboard']);
      else router.navigate(['/user-dashboard']);
      return false;
    }
  }

  return true;
};
