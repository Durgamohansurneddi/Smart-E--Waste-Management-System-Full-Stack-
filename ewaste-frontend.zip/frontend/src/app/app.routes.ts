import { Routes } from '@angular/router';
import { authGuard } from './guards/auth-guard';
import { Role } from './models/auth';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },

  // ─── Public ───────────────────────────────────
  { path: 'home',          loadComponent: () => import('./components/home/home').then(m => m.HomeComponent) },
  { path: 'login',         loadComponent: () => import('./components/login/login').then(m => m.LoginComponent) },
  { path: 'register',      loadComponent: () => import('./components/register/register').then(m => m.RegisterComponent) },
  { path: 'worker-register', loadComponent: () => import('./components/worker-register/worker-register').then(m => m.WorkerRegisterComponent) },
  { path: 'worker-verify-aadhaar', loadComponent: () => import('./components/worker-verify-aadhaar/worker-verify-aadhaar').then(m => m.WorkerVerifyAadhaarComponent) },
  { path: 'forgot-password', loadComponent: () => import('./components/forgot-password/forgot-password').then(m => m.ForgotPasswordComponent) },
  { path: 'verify-otp',     loadComponent: () => import('./components/verify-otp/verify-otp').then(m => m.VerifyOtpComponent) },
  { path: 'reset-password', loadComponent: () => import('./components/reset-password/reset-password').then(m => m.ResetPasswordComponent) },

  // ─── User ─────────────────────────────────────
  { path: 'user-dashboard', canActivate: [authGuard], data: { roles: [Role.USER] },
    loadComponent: () => import('./components/user-dashboard/user-dashboard').then(m => m.UserDashboardComponent) },
  { path: 'user-request',   canActivate: [authGuard], data: { roles: [Role.USER] },
    loadComponent: () => import('./components/user-request/user-request').then(m => m.UserRequestComponent) },

  // ─── Admin ────────────────────────────────────
  { path: 'admin-dashboard', canActivate: [authGuard], data: { roles: [Role.ADMIN] },
    loadComponent: () => import('./components/admin-dashboard/admin-dashboard').then(m => m.AdminDashboardComponent) },
  { path: 'admin-requests',  canActivate: [authGuard], data: { roles: [Role.ADMIN] },
    loadComponent: () => import('./components/admin-ewaste-request/admin-ewaste-request').then(m => m.AdminEwasteRequestComponent) },
  { path: 'admin-workers',   canActivate: [authGuard], data: { roles: [Role.ADMIN] },
    loadComponent: () => import('./components/admin-workers/admin-workers').then(m => m.AdminWorkersComponent) },

  // ─── Worker ───────────────────────────────────
  { path: 'worker-dashboard', canActivate: [authGuard], data: { roles: [Role.WORKER] },
    loadComponent: () => import('./components/worker-dashboard/worker-dashboard').then(m => m.WorkerDashboardComponent) },

  { path: '**', redirectTo: 'home' }
];
